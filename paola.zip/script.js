
    let slideIndex = 0;

    function showSlides() {
        const slides = document.querySelectorAll('.carrossel-images img');
        slides.forEach((slide, index) => {
            slide.style.display = (index === slideIndex) ? 'block' : 'none';
        });
    }

    function moveSlide(n) {
        const slides = document.querySelectorAll('.carrossel-images img');
        slideIndex = (slideIndex + n + slides.length) % slides.length;
        document.querySelector('.carrossel-images').style.transform = `translateX(${-100 * slideIndex}%)`;
    }

    // Inicializa o carrossel
    showSlides();
    setInterval(() => moveSlide(1), 3000); // Muda de imagem a cada 3 segundos

